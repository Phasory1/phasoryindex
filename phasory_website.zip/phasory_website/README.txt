
Phasory Website Package
=======================

Files:
- index.html      : Main HTML landing page
- style.css       : Optional CSS file (empty, styles embedded in HTML)

Instructions:
1. Upload 'index.html' to your web server root or hosting platform.
2. If you want to customize styles, edit 'style.css' and link it properly.
3. The logo image is loaded from Twitter URL directly; you can replace it with your own if needed.
4. The 'Get Started' button smoothly scrolls to the contact form.
5. The contact form uses mailto: to send emails to info@phasory.cc.
